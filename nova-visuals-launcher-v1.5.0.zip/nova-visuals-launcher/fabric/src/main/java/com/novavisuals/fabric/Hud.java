package com.novavisuals.fabric;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiComponent;
import net.minecraft.util.Mth;

/** Приціл, FPS, координати та маркери на екрані. */
public final class Hud {
    private static int frames;
    public static int fps;
    private static long last = System.nanoTime();

    public static void render(PoseStack pose, float partial) {
        Minecraft mc = Minecraft.getInstance();
        int w = mc.getWindow().getGuiScaledWidth(), h = mc.getWindow().getGuiScaledHeight();
        if (mc.player == null || mc.options.hideGui) return;

        frames++;
        long now = System.nanoTime();
        if (now - last >= 1_000_000_000L) { fps = frames; frames = 0; last = now; }

        if (Settings.d.crosshair && mc.options.getCameraType().isFirstPerson()) {
            String[] p = Settings.STYLES[Settings.d.crosshairStyle];
            int col = Settings.COLORS[Settings.d.crosshairColor];
            int s = Math.max(1, Math.min(4, Settings.d.crosshairScale)), ox = w / 2 - (7 * s) / 2, oy = h / 2 - (7 * s) / 2;
            for (int r = 0; r < 7; r++)
                for (int c = 0; c < 7; c++)
                    if (p[r].charAt(c) == 'X')
                        GuiComponent.fill(pose, ox + c * s, oy + r * s, ox + c * s + s, oy + r * s + s, col);
        }

        if (Settings.d.cooldowns) {
            for (int i = 0; i < 9; i++) {
                net.minecraft.world.item.ItemStack st = mc.player.getInventory().getItem(i);
                if (st.isEmpty()) continue;
                float cd = mc.player.getCooldowns().getCooldownPercent(st.getItem(), partial);
                if (cd <= 0f) continue;
                int bx = w / 2 - 88 + i * 20, by = h - 26;
                GuiComponent.fill(pose, bx, by, bx + 16, by + 3, 0xCC0B0B0F);
                GuiComponent.fill(pose, bx, by, bx + Math.max(1, Math.round(16 * cd)), by + 3, 0xFFB855FF);
            }
        }

        if (mc.screen instanceof HudEditScreen) return;   // у режимі редагування малює сам екран
        Widgets.pollMouse();
        Radar.update(mc, partial);
        for (Widgets.W wd : Widgets.ALL) {
            if (!wd.on() || wd.height(mc, false) <= 0) continue;
            int[] r = Widgets.rect(wd, mc, false);
            wd.draw(pose, mc, r[0], r[1], false);
        }
        if (Settings.d.radarOn && Settings.d.radarMode == 2) Radar.tags(pose, mc, Radar.cur, w, h);
    }

    private Hud() { }
}
