package com.novavisuals.fabric;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiComponent;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Віджети HUD, які можна перетягувати (меню: HUD → «Редагувати HUD»): Info, Potions, Enchants, Players Near,
 * Armor, Target, Keystrokes, PvP, Cooldowns, Counters, Shulker, Markers, Friends, Keybinds.
 * Позиція кожного зберігається як частка екрана, тож не залежить від розміру вікна.
 */
public final class Widgets {
    private static final int CARD = 0xDD14141A, MUTED = 0xFF9A93B3, WHITE = 0xFFFFFFFF, GREEN = 0xFF55FF99, GRAY = 0xFF8A84A3, RED = 0xFFFF6B8B, GOLD = 0xFFFFD166;

    public abstract static class W {
        public final String id, title;
        final float dx, dy;

        W(String id, String title, float dx, float dy) { this.id = id; this.title = title; this.dx = dx; this.dy = dy; }

        public abstract boolean on();

        public abstract void setOn(boolean v);

        abstract int width(Minecraft mc, boolean edit);

        /** 0 = у звичайному режимі нічого малювати. */
        abstract int height(Minecraft mc, boolean edit);

        abstract void draw(PoseStack p, Minecraft mc, int x, int y, boolean edit);
    }

    // ---------- примітиви ----------
    public static int accent() { return Settings.THEMES[Math.max(0, Math.min(Settings.THEMES.length - 1, Settings.d.theme))][1]; }

    private static void fill(PoseStack p, int x1, int y1, int x2, int y2, int c) { GuiComponent.fill(p, x1, y1, x2, y2, c); }

    private static void text(PoseStack p, Minecraft mc, String s, int x, int y, int c) { mc.font.drawShadow(p, s, (float) x, (float) y, c); }

    private static void card(PoseStack p, int x, int y, int w, int h) {
        fill(p, x - 1, y - 1, x + w + 1, y + h + 1, 0x55000000 | (accent() & 0xFFFFFF));
        fill(p, x, y, x + w, y + h, CARD);
    }

    private static int chip(PoseStack p, Minecraft mc, int x, int y, String t, int col) {
        int w = mc.font.width(t) + 8;
        fill(p, x, y, x + w, y + 12, CARD);
        fill(p, x, y + 11, x + w, y + 12, 0x66000000 | (accent() & 0xFFFFFF));
        text(p, mc, t, x + 4, y + 2, col);
        return w;
    }

    private static void item(PoseStack p, Minecraft mc, ItemStack st, int x, int y) {
        mc.getItemRenderer().renderGuiItem(st, x, y);
        mc.getItemRenderer().renderGuiItemDecorations(mc.font, st, x, y);
    }

    private static String time(long sec) { long m = sec / 60, s = sec % 60; return (m < 10 ? "0" : "") + m + ":" + (s < 10 ? "0" : "") + s; }

    private static int argb(String hex) { return 0xFF000000 | Integer.parseInt(hex.substring(1), 16); }

    // ---------- дані для PvP-віджетів ----------
    public static LivingEntity lastHit;
    public static long lastHitTick;
    private static int combo, comboTick, prevHurt;
    private static double reach;
    private static final long[][] clicks = new long[2][64];
    private static final int[] clickN = new int[2];
    private static final boolean[] mouseWas = new boolean[2];

    /** Викликається при ударі по істоті. */
    public static void onHit(Minecraft mc, LivingEntity le) {
        if (mc.player == null || mc.level == null) return;
        lastHit = le;
        lastHitTick = mc.level.getGameTime();
        combo++;
        comboTick = (int) (lastHitTick & 0x7fffffff);
        Vec3 eye = mc.player.getEyePosition(1f);
        reach = Math.sqrt(le.getBoundingBox().distanceToSqr(eye));
    }

    /** Щотіку: скидає комбо, коли тебе вдарили або 3 с без ударів. */
    public static void tick(Minecraft mc) {
        if (mc.player == null || mc.level == null) return;
        int hurt = mc.player.hurtTime;
        if (hurt > prevHurt) combo = 0;
        prevHurt = hurt;
        if (combo > 0 && (int) (mc.level.getGameTime() & 0x7fffffff) - comboTick > 60) combo = 0;
    }

    /** Викликається щокадру: рахує кліки для CPS. */
    public static void pollMouse() {
        long win = GLFW.glfwGetCurrentContext();
        if (win == 0L) return;
        long now = System.currentTimeMillis();
        for (int b = 0; b < 2; b++) {
            boolean down = GLFW.glfwGetMouseButton(win, b) == GLFW.GLFW_PRESS;
            if (down && !mouseWas[b]) { clicks[b][clickN[b] % 64] = now; clickN[b]++; }
            mouseWas[b] = down;
        }
    }

    private static int cps(int b) {
        long now = System.currentTimeMillis();
        int n = 0;
        for (int i = 0; i < Math.min(64, clickN[b]); i++) if (now - clicks[b][i] <= 1000L) n++;
        return n;
    }

    // ---------- INFO: чипи як на скріні (бренд, FPS, пінг, час / координати) ----------
    private static double bps;

    private static List<String[]> row1(Minecraft mc) {
        List<String[]> r = new ArrayList<>();
        r.add(new String[]{"Nova Visuals", "#E0A3FF"});
        if (Settings.d.showFps) r.add(new String[]{Hud.fps + " FPS", "#B855FF"});
        if (mc.getConnection() != null && mc.player != null) {
            net.minecraft.client.multiplayer.PlayerInfo pi = mc.getConnection().getPlayerInfo(mc.player.getUUID());
            if (pi != null) r.add(new String[]{pi.getLatency() + " ms", "#55FF99"});
        }
        if (Settings.d.showClock) r.add(new String[]{java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss")), "#FFFFFF"});
        return r;
    }

    private static List<String[]> row2(Minecraft mc) {
        List<String[]> r = new ArrayList<>();
        if (mc.player != null) {
            double v = Math.hypot(mc.player.getX() - mc.player.xo, mc.player.getZ() - mc.player.zo) * 20.0;
            bps += (v - bps) * 0.08;
            if (Settings.d.showCoords) r.add(new String[]{"XYZ " + Math.round(mc.player.getX()) + " / " + Math.round(mc.player.getY()) + " / " + Math.round(mc.player.getZ()) + " (" + mc.player.getDirection().getName() + ")", "#E0A3FF"});
            r.add(new String[]{String.format("%.1f bps", bps), "#FFFFFF"});
            if (Settings.d.showWorldTime && mc.level != null) {
                long dt = mc.level.getDayTime(), tod = ((dt % 24000L) + 24000L) % 24000L;
                r.add(new String[]{String.format("%02d:%02d, день %d", (int) ((tod / 1000L + 6L) % 24L), (int) ((tod % 1000L) * 60L / 1000L), dt / 24000L + 1L), "#B9B2FF"});
            }
        }
        return r;
    }

    private static int rowW(Minecraft mc, List<String[]> row) {
        int w = 0;
        for (String[] c : row) w += mc.font.width(c[0]) + 10;
        return Math.max(0, w - 2);
    }

    private static final W INFO = new W("info", "Info", 0.008f, 0.012f) {
        public boolean on() { return Settings.d.infoOn; }
        public void setOn(boolean v) { Settings.d.infoOn = v; }
        int width(Minecraft mc, boolean edit) { return Math.max(rowW(mc, row1(mc)), rowW(mc, row2(mc))); }
        int height(Minecraft mc, boolean edit) { return mc.player == null ? 0 : (row2(mc).isEmpty() ? 12 : 26); }
        void draw(PoseStack p, Minecraft mc, int x, int y, boolean edit) {
            int cx = x;
            for (String[] c : row1(mc)) cx += chip(p, mc, cx, y, c[0], argb(c[1])) + 2;
            cx = x;
            for (String[] c : row2(mc)) cx += chip(p, mc, cx, y + 14, c[0], argb(c[1])) + 2;
        }
    };

    // ---------- POTIONS ----------
    private static final W POTIONS = new W("potions", "Potions", 0.008f, 0.17f) {
        public boolean on() { return Settings.d.potionsOn; }
        public void setOn(boolean v) { Settings.d.potionsOn = v; }
        private int count(Minecraft mc) { return mc.player == null ? 0 : mc.player.getActiveEffects().size(); }
        int width(Minecraft mc, boolean edit) { return 112; }
        int height(Minecraft mc, boolean edit) { int n = count(mc); return n == 0 ? (edit ? 38 : 0) : 14 + Math.min(n, 8) * 11 + 3; }
        void draw(PoseStack p, Minecraft mc, int x, int y, boolean edit) {
            int n = count(mc);
            card(p, x, y, 112, height(mc, edit));
            text(p, mc, "Potions", x + 4, y + 3, accent());
            int ry = y + 14;
            if (n == 0) { text(p, mc, "Сила II      01:23", x + 4, ry, 0xFFFF9E9E); text(p, mc, "Швидкість     00:45", x + 4, ry + 11, 0xFF9EE7FF); return; }
            int i = 0;
            for (MobEffectInstance e : mc.player.getActiveEffects()) {
                if (i++ >= 8) break;
                String name = new TranslatableComponent(e.getDescriptionId()).getString();
                int amp = e.getAmplifier();
                if (amp > 0) name += " " + (amp < 10 ? new String[]{"", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"}[amp] : String.valueOf(amp + 1));
                int col = Mth.hsvToRgb(Math.abs(e.getDescriptionId().hashCode() % 360) / 360f, 0.45f, 1f) | 0xFF000000;
                text(p, mc, mc.font.plainSubstrByWidth(name, 70), x + 4, ry, col);
                String t = e.getDuration() < 0 ? "inf" : time(e.getDuration() / 20L);
                text(p, mc, t, x + 108 - mc.font.width(t), ry, e.getDuration() >= 0 && e.getDuration() < 200 ? RED : MUTED);
                ry += 11;
            }
        }
    };

    // ---------- ENCHANTS: чари предмета в руці й броні ----------
    private static List<String[]> enchLines(Minecraft mc) {   // {текст, колір}
        List<String[]> l = new ArrayList<>();
        if (mc.player == null) return l;
        ItemStack hand = mc.player.getMainHandItem().isEmpty() ? mc.player.getOffhandItem() : mc.player.getMainHandItem();
        addEnch(l, hand, null);
        if (Settings.d.enchArmor) {
            String[] nm = {"Шолом", "Нагрудник", "Штани", "Черевики"};
            EquipmentSlot[] sl = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            for (int i = 0; i < 4; i++) addEnch(l, mc.player.getItemBySlot(sl[i]), nm[i]);
        }
        return l;
    }

    private static void addEnch(List<String[]> l, ItemStack st, String label) {
        if (st.isEmpty()) return;
        Map<Enchantment, Integer> m = EnchantmentHelper.getEnchantments(st);
        if (m.isEmpty()) return;
        l.add(new String[]{"▸ " + (label != null ? label + ": " : "") + st.getHoverName().getString(), "#E0A3FF"});
        for (Map.Entry<Enchantment, Integer> e : m.entrySet())
            l.add(new String[]{"  " + e.getKey().getFullname(e.getValue()).getString(), e.getKey().isCurse() ? "#FF6B8B" : "#FFFFFF"});
    }

    private static final W ENCHANTS = new W("enchants", "Enchants", 0.80f, 0.40f) {
        public boolean on() { return Settings.d.enchantsOn; }
        public void setOn(boolean v) { Settings.d.enchantsOn = v; }
        int width(Minecraft mc, boolean edit) {
            int w = 90;
            for (String[] s : enchLines(mc)) w = Math.max(w, mc.font.width(s[0]) + 10);
            return Math.min(w, 190);
        }
        int height(Minecraft mc, boolean edit) { int n = Math.min(enchLines(mc).size(), 14); return n == 0 ? (edit ? 38 : 0) : 14 + n * 11 + 3; }
        void draw(PoseStack p, Minecraft mc, int x, int y, boolean edit) {
            List<String[]> l = enchLines(mc);
            int w = width(mc, edit);
            card(p, x, y, w, height(mc, edit));
            text(p, mc, "Enchants", x + 4, y + 3, accent());
            int ry = y + 14;
            if (l.isEmpty()) { text(p, mc, "▸ Алмазний меч", x + 4, ry, 0xFFE0A3FF); text(p, mc, "  Гострота V", x + 4, ry + 11, WHITE); return; }
            for (int i = 0; i < Math.min(l.size(), 14); i++) { text(p, mc, mc.font.plainSubstrByWidth(l.get(i)[0], w - 8), x + 4, ry, argb(l.get(i)[1])); ry += 11; }
        }
    };

    // ---------- KEYBINDS ----------
    private static final W KEYBINDS = new W("keybinds", "Keybinds", 0.008f, 0.42f) {
        public boolean on() { return Settings.d.keybindsOn; }
        public void setOn(boolean v) { Settings.d.keybindsOn = v; }
        private int rows() { return 2 + (Settings.d.animDance ? 1 : 0) + Math.min(Settings.d.binds.size(), 6); }
        int width(Minecraft mc, boolean edit) { return 112; }
        int height(Minecraft mc, boolean edit) { return 14 + rows() * 11 + 3; }
        private void row(PoseStack p, Minecraft mc, int x, int y, String label, int key, boolean held) {
            fill(p, x + 4, y + 3, x + 7, y + 6, held ? GREEN : 0xFF4A4560);
            text(p, mc, mc.font.plainSubstrByWidth(label, 60), x + 10, y, held ? WHITE : MUTED);
            String k = Keys.name(key);
            text(p, mc, k, x + 108 - mc.font.width(k), y, held ? GREEN : accent());
        }
        void draw(PoseStack p, Minecraft mc, int x, int y, boolean edit) {
            card(p, x, y, 112, height(mc, edit));
            text(p, mc, "Keybinds", x + 4, y + 3, accent());
            int ry = y + 14;
            row(p, mc, x, ry, "Меню", GLFW.GLFW_KEY_RIGHT_SHIFT, Keys.rightShift()); ry += 11;
            row(p, mc, x, ry, "Радар", GLFW.GLFW_KEY_V, Keys.down(GLFW.GLFW_KEY_V)); ry += 11;
            if (Settings.d.animDance) { row(p, mc, x, ry, "Танець", GLFW.GLFW_KEY_G, Keys.down(GLFW.GLFW_KEY_G)); ry += 11; }
            int i = 0;
            for (Settings.Bind b : Settings.d.binds) { if (i++ >= 6) break; row(p, mc, x, ry, b.cmd, b.key, Keys.down(b.key)); ry += 11; }
        }
    };

    // ---------- TARGET ----------
    private static LivingEntity target(Minecraft mc) {
        if (mc.crosshairPickEntity instanceof LivingEntity le) return le;
        LivingEntity last = lastHit;
        if (last != null && last.isAlive() && mc.level != null && mc.level.getGameTime() - lastHitTick < 100L) return last;
        return null;
    }

    private static final W TARGET = new W("target", "Target", 0.40f, 0.60f) {
        public boolean on() { return Settings.d.showHealth; }
        public void setOn(boolean v) { Settings.d.showHealth = v; }
        int width(Minecraft mc, boolean edit) { return 124; }
        int height(Minecraft mc, boolean edit) { return target(mc) != null || edit ? 30 : 0; }
        void draw(PoseStack p, Minecraft mc, int x, int y, boolean edit) {
            LivingEntity t = target(mc);
            String name = t != null ? t.getName().getString() : "Target_Player";
            float hp = t != null ? t.getHealth() : 14f, mhp = t != null ? t.getMaxHealth() : 20f;
            double dist = t != null && mc.player != null ? mc.player.distanceTo(t) : 4.2;
            card(p, x, y, 124, 30);
            fill(p, x + 4, y + 7, x + 20, y + 23, 0xFF2C2745);
            String ch = name.substring(0, 1).toUpperCase();
            text(p, mc, ch, x + 12 - mc.font.width(ch) / 2, y + 11, accent());
            text(p, mc, mc.font.plainSubstrByWidth(name, 70), x + 24, y + 4, WHITE);
            String d = String.format("%.1fм", dist);
            text(p, mc, d, x + 120 - mc.font.width(d), y + 4, MUTED);
            float f = Math.max(0f, Math.min(1f, hp / Math.max(1f, mhp)));
            fill(p, x + 24, y + 17, x + 100, y + 22, 0xFF2C2745);
            fill(p, x + 24, y + 17, x + 24 + Math.round(76 * f), y + 22, f > 0.5f ? GREEN : f > 0.25f ? GOLD : RED);
            String s = String.valueOf(Math.round(hp));
            text(p, mc, s, x + 120 - mc.font.width(s), y + 16, WHITE);
        }
    };

    // ---------- ARMOR (з іконками) ----------
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final Item[] SAMPLE_ARMOR = {Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS};

    private static final W ARMOR = new W("armor", "Armor", 0.90f, 0.30f) {
        public boolean on() { return Settings.d.showArmor; }
        public void setOn(boolean v) { Settings.d.showArmor = v; }
        private int count(Minecraft mc) { int n = 0; if (mc.player != null) for (EquipmentSlot s : SLOTS) if (!mc.player.getItemBySlot(s).isEmpty()) n++; return n; }
        int width(Minecraft mc, boolean edit) { return 62; }
        int height(Minecraft mc, boolean edit) { int n = count(mc); return n == 0 ? (edit ? 4 * 20 + 6 : 0) : n * 20 + 6; }
        void draw(PoseStack p, Minecraft mc, int x, int y, boolean edit) {
            boolean sample = count(mc) == 0;
            card(p, x, y, 62, height(mc, edit));
            int ry = y + 3;
            for (int i = 0; i < 4; i++) {
                ItemStack st = sample ? new ItemStack(SAMPLE_ARMOR[i]) : mc.player.getItemBySlot(SLOTS[i]);
                if (st.isEmpty()) continue;
                item(p, mc, st, x + 3, ry);
                int pct = st.isDamageableItem() ? 100 - st.getDamageValue() * 100 / Math.max(1, st.getMaxDamage()) : 100;
                int col = pct > 50 ? GREEN : pct > 20 ? GOLD : RED;
                text(p, mc, pct + "%", x + 22, ry + 1, col);
                fill(p, x + 22, ry + 12, x + 58, ry + 14, 0xFF2C2745);
                fill(p, x + 22, ry + 12, x + 22 + Math.round(36 * pct / 100f), ry + 14, col);
                ry += 20;
            }
        }
    };

    // ---------- KEYSTROKES + CPS ----------
    private static void key(PoseStack p, Minecraft mc, int x, int y, int w, int h, String label, boolean down) {
        fill(p, x, y, x + w, y + h, down ? (0xCC000000 | (accent() & 0xFFFFFF)) : CARD);
        fill(p, x, y + h - 1, x + w, y + h, 0x66000000 | (accent() & 0xFFFFFF));
        text(p, mc, label, x + w / 2 - mc.font.width(label) / 2, y + h / 2 - 4, down ? WHITE : MUTED);
    }

    private static final W KEYS = new W("keys", "Keystrokes", 0.45f, 0.78f) {
        public boolean on() { return Settings.d.keysOn; }
        public void setOn(boolean v) { Settings.d.keysOn = v; }
        int width(Minecraft mc, boolean edit) { return 65; }
        int height(Minecraft mc, boolean edit) { return mc.player == null ? 0 : 80; }
        void draw(PoseStack p, Minecraft mc, int x, int y, boolean edit) {
            var o = mc.options;
            key(p, mc, x + 22, y, 21, 20, "W", o.keyUp.isDown());
            key(p, mc, x, y + 22, 21, 20, "A", o.keyLeft.isDown());
            key(p, mc, x + 22, y + 22, 21, 20, "S", o.keyDown.isDown());
            key(p, mc, x + 44, y + 22, 21, 20, "D", o.keyRight.isDown());
            key(p, mc, x, y + 44, 32, 20, "LMB " + cps(0), o.keyAttack.isDown());
            key(p, mc, x + 33, y + 44, 32, 20, "RMB " + cps(1), o.keyUse.isDown());
            key(p, mc, x, y + 66, 65, 12, "━━", o.keyJump.isDown());
        }
    };

    // ---------- PVP: комбо, дистанція удару, CPS ----------
    private static final W PVP = new W("pvp", "PvP", 0.45f, 0.70f) {
        public boolean on() { return Settings.d.pvpOn; }
        public void setOn(boolean v) { Settings.d.pvpOn = v; }
        int width(Minecraft mc, boolean edit) { return 84; }
        int height(Minecraft mc, boolean edit) { return mc.player == null ? 0 : (combo > 0 || edit ? 40 : 0); }
        void draw(PoseStack p, Minecraft mc, int x, int y, boolean edit) {
            card(p, x, y, 84, 40);
            text(p, mc, "PvP", x + 4, y + 3, accent());
            text(p, mc, "Combo", x + 4, y + 14, MUTED);
            String c = String.valueOf(edit && combo == 0 ? 5 : combo);
            text(p, mc, c, x + 80 - mc.font.width(c), y + 14, combo >= 5 ? GOLD : WHITE);
            text(p, mc, "Reach", x + 4, y + 26, MUTED);
            String r = String.format("%.2f", edit && reach == 0 ? 2.94 : reach);
            text(p, mc, r, x + 80 - mc.font.width(r), y + 26, reach > 3.05 ? RED : GREEN);
        }
    };

    // ---------- COOLDOWNS (перли, яблука, щит тощо) ----------
    private static Map<String, Float> cooldowns(Minecraft mc) {
        Map<String, Float> m = new LinkedHashMap<>();
        if (mc.player == null) return m;
        List<ItemStack> all = new ArrayList<>(mc.player.getInventory().items);
        all.addAll(mc.player.getInventory().offhand);
        for (ItemStack st : all) {
            if (st.isEmpty()) continue;
            float cd = mc.player.getCooldowns().getCooldownPercent(st.getItem(), 0f);
            if (cd > 0f) m.putIfAbsent(st.getHoverName().getString(), cd);
        }
        return m;
    }

    private static final W COOLDOWNS = new W("cooldowns", "Cooldown", 0.80f, 0.62f) {
        public boolean on() { return Settings.d.cdOn; }
        public void setOn(boolean v) { Settings.d.cdOn = v; }
        int width(Minecraft mc, boolean edit) { return 112; }
        int height(Minecraft mc, boolean edit) { int n = Math.min(cooldowns(mc).size(), 6); return n == 0 ? (edit ? 38 : 0) : 14 + n * 13 + 3; }
        void draw(PoseStack p, Minecraft mc, int x, int y, boolean edit) {
            Map<String, Float> m = cooldowns(mc);
            card(p, x, y, 112, height(mc, edit));
            text(p, mc, "Cooldown", x + 4, y + 3, accent());
            int ry = y + 14;
            if (m.isEmpty()) { text(p, mc, "Ендер-перл", x + 4, ry, WHITE); fill(p, x + 4, ry + 9, x + 70, ry + 11, accent()); return; }
            int i = 0;
            for (Map.Entry<String, Float> e : m.entrySet()) {
                if (i++ >= 6) break;
                text(p, mc, mc.font.plainSubstrByWidth(e.getKey(), 104), x + 4, ry, WHITE);
                fill(p, x + 4, ry + 9, x + 108, ry + 11, 0xFF2C2745);
                fill(p, x + 4, ry + 9, x + 4 + Math.round(104 * e.getValue()), ry + 11, accent());
                ry += 13;
            }
        }
    };

    // ---------- COUNTERS: тотеми, перли, яблука, кристали, обсидіан ----------
    private static final Item[] COUNT_ITEMS = {Items.TOTEM_OF_UNDYING, Items.ENDER_PEARL, Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE, Items.END_CRYSTAL, Items.OBSIDIAN};

    private static int countOf(Minecraft mc, Item it) {
        int n = 0;
        if (mc.player == null) return 0;
        for (ItemStack st : mc.player.getInventory().items) if (st.getItem() == it) n += st.getCount();
        for (ItemStack st : mc.player.getInventory().offhand) if (st.getItem() == it) n += st.getCount();
        return n;
    }

    private static final W COUNTERS = new W("counters", "Counters", 0.80f, 0.20f) {
        public boolean on() { return Settings.d.countersOn; }
        public void setOn(boolean v) { Settings.d.countersOn = v; }
        private int shown(Minecraft mc) { int n = 0; for (Item it : COUNT_ITEMS) if (countOf(mc, it) > 0) n++; return n; }
        int width(Minecraft mc, boolean edit) { return 56; }
        int height(Minecraft mc, boolean edit) { int n = shown(mc); return n == 0 ? (edit ? 3 * 18 + 6 : 0) : n * 18 + 6; }
        void draw(PoseStack p, Minecraft mc, int x, int y, boolean edit) {
            boolean sample = shown(mc) == 0;
            card(p, x, y, 56, height(mc, edit));
            int ry = y + 3, k = 0;
            for (Item it : COUNT_ITEMS) {
                int c = sample ? (k < 3 ? 3 - k : 0) : countOf(mc, it);
                if (c <= 0) continue;
                mc.getItemRenderer().renderGuiItem(new ItemStack(it), x + 3, ry);
                text(p, mc, "x" + c, x + 24, ry + 5, c <= 1 ? RED : WHITE);
                ry += 18; k++;
            }
        }
    };

    // ---------- SHULKER у руці ----------
    private static final W SHULKER = new W("shulker", "Shulker", 0.30f, 0.30f) {
        public boolean on() { return Settings.d.shulkerOn; }
        public void setOn(boolean v) { Settings.d.shulkerOn = v; }
        int width(Minecraft mc, boolean edit) { return ShulkerPreview.panelW(); }
        int height(Minecraft mc, boolean edit) { return !ShulkerPreview.held(mc).isEmpty() || edit ? ShulkerPreview.panelH() : 0; }
        void draw(PoseStack p, Minecraft mc, int x, int y, boolean edit) {
            ItemStack st = ShulkerPreview.held(mc);
            if (st.isEmpty()) st = new ItemStack(Items.PURPLE_SHULKER_BOX);
            ShulkerPreview.panel(p, mc, st, x, y, 1f);
        }
    };

    // ---------- MARKERS ----------
    private static List<String> markerLines(Minecraft mc) {
        List<String> l = new ArrayList<>();
        if (mc.level == null || mc.player == null) return l;
        String dim = mc.level.dimension().location().toString();
        for (Settings.Marker m : Settings.d.markers) {
            if (!dim.equals(m.dim)) continue;
            double dx = m.x - mc.player.getX(), dz = m.z - mc.player.getZ(), dy = m.y - mc.player.getY();
            double rel = Mth.wrapDegrees(-Math.toDegrees(Math.atan2(dx, dz)) - mc.player.getYRot());
            String a = Math.abs(rel) <= 45 ? "^" : Math.abs(rel) >= 135 ? "v" : (rel > 0 ? ">" : "<");
            l.add("[" + a + "] " + m.name + "  " + Math.round(Math.sqrt(dx * dx + dy * dy + dz * dz)) + "м");
            if (l.size() >= 8) break;
        }
        return l;
    }

    private static final W MARKERS = new W("markers", "Markers", 0.78f, 0.02f) {
        public boolean on() { return Settings.d.showMarkers; }
        public void setOn(boolean v) { Settings.d.showMarkers = v; }
        int width(Minecraft mc, boolean edit) { return 112; }
        int height(Minecraft mc, boolean edit) { int n = markerLines(mc).size(); return n == 0 ? (edit ? 38 : 0) : 14 + n * 11 + 3; }
        void draw(PoseStack p, Minecraft mc, int x, int y, boolean edit) {
            List<String> l = markerLines(mc);
            card(p, x, y, 112, height(mc, edit));
            text(p, mc, "Markers", x + 4, y + 3, accent());
            int ry = y + 14;
            if (l.isEmpty()) { text(p, mc, "[^] Дім  120м", x + 4, ry, WHITE); text(p, mc, "[>] Шахта  340м", x + 4, ry + 11, WHITE); return; }
            for (String s : l) { text(p, mc, mc.font.plainSubstrByWidth(s, 104), x + 4, ry, WHITE); ry += 11; }
        }
    };

    // ---------- FRIENDS ----------
    private static List<NovaNet.Friend> onlineFriends() {
        List<NovaNet.Friend> l = new ArrayList<>();
        for (NovaNet.Friend f : NovaNet.friends) if (f.online) l.add(f);
        return l;
    }

    private static final W FRIENDS = new W("friends", "Friends", 0.78f, 0.30f) {
        public boolean on() { return Settings.d.showFriends; }
        public void setOn(boolean v) { Settings.d.showFriends = v; }
        int width(Minecraft mc, boolean edit) { return 124; }
        int height(Minecraft mc, boolean edit) { int n = Math.min(6, onlineFriends().size()); return n == 0 ? (edit ? 38 : 0) : 14 + n * 11 + 3; }
        void draw(PoseStack p, Minecraft mc, int x, int y, boolean edit) {
            List<NovaNet.Friend> l = onlineFriends();
            card(p, x, y, 124, height(mc, edit));
            text(p, mc, "Friends", x + 4, y + 3, accent());
            int ry = y + 14;
            if (l.isEmpty()) { text(p, mc, "● Alex  у грі", x + 4, ry, GREEN); text(p, mc, "● Maria  в лаунчері", x + 4, ry + 11, GREEN); return; }
            int i = 0;
            for (NovaNet.Friend f : l) {
                if (i++ >= 6) break;
                String s = "● " + f.name + (f.inGame ? (f.server.isEmpty() ? "  у грі" : "  " + f.server) : "  лаунчер");
                text(p, mc, mc.font.plainSubstrByWidth(s, 116), x + 4, ry, GREEN);
                ry += 11;
            }
        }
    };

    // ---------- RADAR / PLAYERS NEAR (список чи карта; картки на екрані малює Hud) ----------
    private static final W RADAR = new W("radar", "Players Near", 0.008f, 0.58f) {
        public boolean on() { return Settings.d.radarOn; }
        public void setOn(boolean v) { Settings.d.radarOn = v; }
        private boolean world() { return Settings.d.radarMode == 2; }
        int width(Minecraft mc, boolean edit) { return world() ? 90 : Settings.d.radarMode == 1 ? Radar.mapSize() : Radar.listW(); }
        int height(Minecraft mc, boolean edit) {
            if (world()) return edit ? 22 : 0;
            if (Settings.d.radarMode == 1) return Radar.mapSize();
            List<Radar.T> l = Radar.cur.isEmpty() && edit ? Radar.sample() : Radar.cur;
            return Radar.listH(l);
        }
        void draw(PoseStack p, Minecraft mc, int x, int y, boolean edit) {
            List<Radar.T> l = Radar.cur.isEmpty() && edit ? Radar.sample() : Radar.cur;
            if (world()) { card(p, x, y, 90, 22); text(p, mc, "Картки на екрані", x + 4, y + 7, MUTED); return; }
            if (Settings.d.radarMode == 1) Radar.map(p, mc, l, x, y); else Radar.list(p, mc, l, x, y);
        }
    };

    public static final List<W> ALL = List.of(INFO, POTIONS, ENCHANTS, KEYBINDS, RADAR, TARGET, ARMOR, KEYS, PVP, COOLDOWNS, COUNTERS, SHULKER, MARKERS, FRIENDS);

    // ---------- позиції ----------
    /** {x, y, w, h} у координатах екрана GUI. */
    public static int[] rect(W w, Minecraft mc, boolean edit) {
        int sw = mc.getWindow().getGuiScaledWidth(), sh = mc.getWindow().getGuiScaledHeight();
        float[] pos = Settings.d.hudPos.get(w.id);
        float fx = pos != null && pos.length >= 2 ? pos[0] : w.dx, fy = pos != null && pos.length >= 2 ? pos[1] : w.dy;
        int ww = w.width(mc, edit), hh = Math.max(1, w.height(mc, edit));
        int x = Math.max(0, Math.min(sw - ww, Math.round(fx * sw))), y = Math.max(0, Math.min(sh - hh, Math.round(fy * sh)));
        return new int[]{x, y, ww, hh};
    }

    public static void setPos(W w, Minecraft mc, int x, int y) {
        int sw = mc.getWindow().getGuiScaledWidth(), sh = mc.getWindow().getGuiScaledHeight();
        Settings.d.hudPos.put(w.id, new float[]{x / (float) sw, y / (float) sh});
    }

    public static void resetPositions() { Settings.d.hudPos.clear(); Settings.save(); }

    private Widgets() { }
}
