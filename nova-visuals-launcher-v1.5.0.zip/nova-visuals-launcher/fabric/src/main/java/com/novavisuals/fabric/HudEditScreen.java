package com.novavisuals.fabric;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiComponent;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.TextComponent;

/**
 * Режим редагування HUD: меню зникає, лишаються тільки віджети. Тягни їх мишею (ліва кнопка),
 * права кнопка вмикає/вимикає віджет. «Готово» повертає в меню.
 */
public class HudEditScreen extends Screen {
    private final int returnTab;
    private Widgets.W drag;
    private int offX, offY;
    private boolean leftPrev = true, rightPrev = true;   // кнопка ще може бути затиснута після кліку в меню
    private Button done, reset;

    public HudEditScreen(int returnTab) {
        super(new TextComponent("HUD"));
        this.returnTab = returnTab;
    }

    @Override
    protected void init() {
        done = new Button(width / 2 - 104, 8, 100, 20, new TextComponent("Готово"), b -> onClose());
        reset = new Button(width / 2 + 4, 8, 100, 20, new TextComponent("Скинути позиції"), b -> Widgets.resetPositions());
        addRenderableWidget(done);
        addRenderableWidget(reset);
    }

    @Override
    public boolean isPauseScreen() { return false; }

    @Override
    public void onClose() {
        Settings.save();
        MenuScreen.openAt(returnTab);
    }

    @Override
    public void render(PoseStack p, int mx, int my, float pt) {
        Minecraft mc = Minecraft.getInstance();
        GuiComponent.fill(p, 0, 0, width, height, 0x44000000);
        Radar.update(mc, pt);
        boolean left = Keys.mouse(0), right = Keys.mouse(1);
        boolean overButtons = done.isMouseOver(mx, my) || reset.isMouseOver(mx, my);
        int acc = Widgets.accent();

        for (Widgets.W w : Widgets.ALL) {
            int[] r = Widgets.rect(w, mc, true);
            w.draw(p, mc, r[0], r[1], true);
            int col = drag == w ? 0xFF55FF99 : w.on() ? acc : 0xFFFF6B8B;
            GuiComponent.fill(p, r[0] - 2, r[1] - 2, r[0] + r[2] + 2, r[1] - 1, col);
            GuiComponent.fill(p, r[0] - 2, r[1] + r[3] + 1, r[0] + r[2] + 2, r[1] + r[3] + 2, col);
            GuiComponent.fill(p, r[0] - 2, r[1] - 2, r[0] - 1, r[1] + r[3] + 2, col);
            GuiComponent.fill(p, r[0] + r[2] + 1, r[1] - 2, r[0] + r[2] + 2, r[1] + r[3] + 2, col);
            if (!w.on()) {
                GuiComponent.fill(p, r[0], r[1], r[0] + r[2], r[1] + r[3], 0x99000000);
                mc.font.drawShadow(p, "ВИМК.", r[0] + 4, r[1] + r[3] / 2f - 4, 0xFFFF6B8B);
            }
            mc.font.drawShadow(p, w.title, r[0], r[1] - 11, col);
        }

        if (left && !leftPrev && !overButtons) {
            for (int i = Widgets.ALL.size() - 1; i >= 0; i--) {
                Widgets.W w = Widgets.ALL.get(i);
                int[] r = Widgets.rect(w, mc, true);
                if (mx >= r[0] && mx <= r[0] + r[2] && my >= r[1] && my <= r[1] + r[3]) { drag = w; offX = mx - r[0]; offY = my - r[1]; break; }
            }
        }
        if (drag != null && left) {
            int[] r = Widgets.rect(drag, mc, true);
            Widgets.setPos(drag, mc, Math.max(0, Math.min(width - r[2], ((mx - offX) / 2) * 2)), Math.max(0, Math.min(height - r[3], ((my - offY) / 2) * 2)));
        }
        if (!left && drag != null) { drag = null; Settings.save(); }

        if (right && !rightPrev && !overButtons) {
            for (int i = Widgets.ALL.size() - 1; i >= 0; i--) {
                Widgets.W w = Widgets.ALL.get(i);
                int[] r = Widgets.rect(w, mc, true);
                if (mx >= r[0] && mx <= r[0] + r[2] && my >= r[1] && my <= r[1] + r[3]) { w.setOn(!w.on()); Settings.save(); break; }
            }
        }
        leftPrev = left;
        rightPrev = right;

        done.render(p, mx, my, pt);
        reset.render(p, mx, my, pt);
        String hint = "Тягни віджети мишею  ·  ПКМ: вимкнути / увімкнути  ·  Готово: назад у меню";
        mc.font.drawShadow(p, hint, width / 2f - mc.font.width(hint) / 2f, 34, 0xFFE0A3FF);
    }
}
