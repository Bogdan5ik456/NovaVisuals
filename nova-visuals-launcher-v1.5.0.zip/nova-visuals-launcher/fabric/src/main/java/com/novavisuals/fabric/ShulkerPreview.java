package com.novavisuals.fabric;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.novavisuals.fabric.mixin.AbstractContainerScreenAccessor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiComponent;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import org.lwjgl.glfw.GLFW;

/**
 * Shulker Preview: навів на шалкер у інвентарі чи сундуці - збоку сітка з вмістом; утримуй V - велике вікно;
 * шалкер у руці теж показується (віджет). Панель має колір самого шалкера.
 */
public final class ShulkerPreview {
    private static final int DEFAULT = 0x956795;   // колір нефарбованого шалкера

    public static boolean isShulker(ItemStack s) {
        return !s.isEmpty() && s.getItem() instanceof BlockItem bi && bi.getBlock() instanceof ShulkerBoxBlock;
    }

    public static int color(ItemStack s) {
        if (!isShulker(s) || !Settings.d.shulkerTint) return DEFAULT;
        DyeColor c = ((ShulkerBoxBlock) ((BlockItem) s.getItem()).getBlock()).getColor();
        return c == null ? DEFAULT : c.getMaterialColor().col;
    }

    public static ItemStack[] read(ItemStack s) {
        ItemStack[] out = new ItemStack[27];
        for (int i = 0; i < 27; i++) out[i] = ItemStack.EMPTY;
        CompoundTag tag = s.getTagElement("BlockEntityTag");
        if (tag == null || !tag.contains("Items", 9)) return out;
        ListTag list = tag.getList("Items", 10);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag it = list.getCompound(i);
            int slot = it.getByte("Slot") & 255;
            if (slot < 27) out[slot] = ItemStack.of(it);
        }
        return out;
    }

    public static ItemStack held(Minecraft mc) {
        if (mc.player == null) return ItemStack.EMPTY;
        if (isShulker(mc.player.getMainHandItem())) return mc.player.getMainHandItem();
        if (isShulker(mc.player.getOffhandItem())) return mc.player.getOffhandItem();
        return ItemStack.EMPTY;
    }

    private static int mix(int a, int b, float t) {   // t: частка b
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t), g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t), bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    public static int panelW() { return 9 * 18 + 12; }

    public static int panelH() { return 3 * 18 + 26; }

    /** Малює панель у (x, y) із масштабом sc (1 - підказка, ~1.8 - велике вікно). */
    public static void panel(PoseStack p, Minecraft mc, ItemStack shulker, int x, int y, float sc) {
        int col = color(shulker);
        int bg = mix(col, 0x0B0B0F, 0.82f), edge = col | 0xFF000000, slotBg = mix(col, 0x000000, 0.62f), soft = mix(col, 0xFFFFFF, 0.55f);
        ItemStack[] items = read(shulker);
        p.pushPose();
        p.translate(x, y, 300);
        p.scale(sc, sc, 1f);
        com.mojang.blaze3d.vertex.PoseStack mv = RenderSystem.getModelViewStack();
        mv.pushPose();
        mv.translate(x, y, 0);
        mv.scale(sc, sc, 1f);
        RenderSystem.applyModelViewMatrix();
        int w = panelW(), h = panelH();
        GuiComponent.fill(p, -1, -1, w + 1, h + 1, edge);
        GuiComponent.fill(p, 0, 0, w, h, bg);
        String title = shulker.isEmpty() ? "Shulker Preview" : shulker.getHoverName().getString();
        mc.font.drawShadow(p, mc.font.plainSubstrByWidth(title, w - 8), 6, 4, soft);
        boolean empty = true;
        for (int i = 0; i < 27; i++) {
            int sx = 6 + (i % 9) * 18, sy = 16 + (i / 9) * 18;
            GuiComponent.fill(p, sx, sy, sx + 17, sy + 17, slotBg);
            if (!items[i].isEmpty()) empty = false;
        }
        for (int i = 0; i < 27; i++) {
            if (items[i].isEmpty()) continue;
            int sx = 7 + (i % 9) * 18, sy = 17 + (i / 9) * 18;
            mc.getItemRenderer().renderGuiItem(items[i], sx, sy);
            mc.getItemRenderer().renderGuiItemDecorations(mc.font, items[i], sx, sy);
        }
        if (empty) mc.font.drawShadow(p, "Порожній", w / 2f - mc.font.width("Порожній") / 2f, 34, soft);
        mc.font.drawShadow(p, "V - велике вікно", w - mc.font.width("V - велике вікно") - 5, h - 10, mix(col, 0xFFFFFF, 0.3f));
        mv.popPose();
        RenderSystem.applyModelViewMatrix();
        p.popPose();
    }

    /** Викликається після малювання будь-якого екрана з інвентарем. */
    public static void renderHover(AbstractContainerScreen<?> screen, PoseStack p, int mx, int my) {
        if (!Settings.d.shulkerHover) return;
        Slot slot = ((AbstractContainerScreenAccessor) screen).nv$getHoveredSlot();
        if (slot == null || !slot.hasItem()) return;
        ItemStack st = slot.getItem();
        if (!isShulker(st)) return;
        Minecraft mc = Minecraft.getInstance();
        long win = GLFW.glfwGetCurrentContext();
        boolean big = win != 0L && GLFW.glfwGetKey(win, GLFW.GLFW_KEY_V) == GLFW.GLFW_PRESS;
        float sc = big ? 1.9f : 1f;
        int w = Math.round(panelW() * sc), h = Math.round(panelH() * sc);
        int x, y;
        if (big) { x = (screen.width - w) / 2; y = (screen.height - h) / 2; }
        else {   // ліворуч від курсора, щоб не перекривати ванільну підказку; якщо тісно - праворуч нижче
            x = mx - w - 8; y = my - 8;
            if (x < 4) { x = mx + 14; y = my + 18; }
            y = Math.max(4, Math.min(screen.height - h - 4, y));
            x = Math.max(4, Math.min(screen.width - w - 4, x));
        }
        panel(p, mc, st, x, y, sc);
    }

    private ShulkerPreview() { }
}
