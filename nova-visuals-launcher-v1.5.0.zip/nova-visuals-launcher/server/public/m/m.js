(() => {
  'use strict';
  const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
  const store = {
    get(k, d) { try { const v = localStorage.getItem('nv.' + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
    set(k, v) { try { localStorage.setItem('nv.' + k, JSON.stringify(v)); } catch {} }
  };
  const el = (t, c, x) => { const e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; };
  let toastT = null;
  function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2600); }

  // ---------- Android-застосунок: рідний міст (запуск гри, файли) ----------
  const NP = (window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()) ? window.Capacitor.registerPlugin('NovaPlatform') : null;
  if (NP) document.body.classList.add('native');
  const GAME_DEF = '/storage/emulated/0/NovaVisuals/game';
  const gameDir = () => (store.get('gameDir', GAME_DEF) || GAME_DEF).replace(/\/+$/, '');
  const APP_PKGS = {
    pojav: ['net.kdt.pojavlaunch', 'net.kdt.pojavlaunch.debug', 'org.angelauramc.amethyst'],
    zalith: ['com.movtery.zalithlauncher', 'com.movtery.pojavzh'],
    fcl: ['com.tungsten.fcl']
  };

  // ---------- навігація ----------
  function go(p) {
    $$('.page').forEach(x => x.classList.toggle('active', x.id === 'p-' + p));
    $$('nav button').forEach(b => b.classList.toggle('active', b.dataset.p === p));
    if (p === 'friends') loadFriends();
    if (p === 'mods' && !$('#mlist').children.length) searchMods(true);
    window.scrollTo(0, 0);
    try { history.replaceState(null, '', '#' + p); } catch {}
  }
  $$('nav button').forEach(b => b.addEventListener('click', () => go(b.dataset.p)));
  $$('.ver').forEach(b => b.addEventListener('click', () => { if (b.classList.contains('off')) toast('1.21.11 на телефоні поки недоступна'); }));

  // ---------- бібліотека модів (Modrinth, як у ПК-лаунчері) ----------
  const MC = '1.18.2', FABRIC_API = 'P7dR8mSH';
  let kind = 'mods', offset = 0;
  async function mr(p) {
    const r = await fetch('https://api.modrinth.com/v2' + p);
    if (!r.ok) throw new Error('Modrinth: помилка ' + r.status);
    return r.json();
  }
  async function latest(k, project) {
    let url = `/project/${encodeURIComponent(project)}/version?game_versions=${encodeURIComponent(JSON.stringify([MC]))}`;
    if (k !== 'packs') url += `&loaders=${encodeURIComponent(JSON.stringify(['fabric']))}`;
    const vs = await mr(url);
    return vs[0] || null;
  }
  const installed = () => store.get('installed', []);
  async function searchMods(reset) {
    if (reset) { offset = 0; $('#mlist').textContent = ''; }
    $('#merr').textContent = '';
    const q = $('#q').value.trim().slice(0, 60);
    const facets = [[`project_type:${kind === 'packs' ? 'resourcepack' : 'mod'}`], [`versions:${MC}`]];
    if (kind !== 'packs') facets.push(['categories:fabric']);
    try {
      const r = await mr(`/search?query=${encodeURIComponent(q)}&facets=${encodeURIComponent(JSON.stringify(facets))}&limit=20&offset=${offset}&index=${q ? 'relevance' : 'downloads'}`);
      const have = new Set(installed().map(x => x.id));
      r.hits.forEach(h => {
        const it = el('div', 'item'), img = el('img', 'ic'); img.src = h.icon_url || 'img/icon.svg'; img.alt = ''; img.loading = 'lazy';
        const tx = el('div', 'tx'); tx.appendChild(el('b', '', h.title)); tx.appendChild(el('small', '', h.description));
        const b = el('button', 'btn sm' + (have.has(h.project_id) ? '' : ' primary'), have.has(h.project_id) ? 'Скачано ✓' : 'Скачати');
        b.addEventListener('click', () => installProject(h, b));
        it.append(img, tx, b); $('#mlist').appendChild(it);
      });
      offset += r.hits.length;
      $('#mmore').classList.toggle('hidden', r.hits.length < 20);
      if (!$('#mlist').children.length) $('#mlist').textContent = 'Нічого не знайдено';
    } catch (e) { $('#merr').textContent = e.message; }
  }
  async function dl(files, sub) {
    if (NP) {   // в Android-застосунку кладемо файли просто в папку гри
      try {
        for (const f of files) await NP.download({ url: f.url, path: gameDir() + '/' + (sub || 'mods') + '/' + f.filename });
        return;
      } catch (e) {
        toast('Не вдалося зберегти в папку гри: ' + (e.message || e) + '. Дай доступ до файлів у Профілі.');
        return;
      }
    }
    for (const f of files) {
      const a = document.createElement('a'); a.href = f.url; a.download = f.filename; a.rel = 'noopener';
      document.body.appendChild(a); a.click(); a.remove();
      await new Promise(r => setTimeout(r, 900));
    }
  }
  const fileOf = v => v.files.find(f => f.primary) || v.files[0];
  async function installProject(h, btn) {
    btn.disabled = true; btn.textContent = '…';
    try {
      const v = await latest(kind, h.project_id);
      if (!v) throw new Error('Немає версії для ' + MC);
      const files = [fileOf(v)];
      if (kind !== 'packs') {   // обов'язкові залежності (як у ПК-лаунчері)
        for (const d of v.dependencies || []) {
          if (d.dependency_type !== 'required' || !d.project_id) continue;
          const dv = await latest('mods', d.project_id).catch(() => null);
          if (dv && !files.some(f => f.filename === fileOf(dv).filename)) files.push(fileOf(dv));
        }
      }
      await dl(files, kind === 'packs' ? 'resourcepacks' : 'mods');
      const list = installed().filter(x => x.id !== h.project_id); list.push({ id: h.project_id, title: h.title }); store.set('installed', list);
      btn.textContent = 'Скачано ✓'; btn.classList.remove('primary');
      toast(files.length > 1 ? `Встановлено файлів: ${files.length} (з залежностями)` : (NP ? 'Встановлено в папку гри' : 'Файл скачано: поклади його в папку mods'));
    } catch (e) { btn.textContent = 'Скачати'; toast(e.message); }
    btn.disabled = false;
  }
  $$('#p-mods .seg button').forEach(b => b.addEventListener('click', () => {
    $$('#p-mods .seg button').forEach(x => x.classList.toggle('active', x === b)); kind = b.dataset.k; searchMods(true);
  }));
  $('#qgo').addEventListener('click', () => searchMods(true));
  $('#q').addEventListener('keydown', e => { if (e.key === 'Enter') searchMods(true); });
  $('#mmore').addEventListener('click', () => searchMods(false));
  $('#dl-fabric').addEventListener('click', async () => {
    try { const v = await latest('mods', FABRIC_API); if (!v) throw new Error('Fabric API для 1.18.2 не знайдено'); await dl([fileOf(v)], 'mods'); toast(NP ? 'Fabric API встановлено' : 'Fabric API скачано'); } catch (e) { toast(e.message); }
  });

  // ---------- косметика ----------
  const WINGS = [['shadow', 'Крила тіні'], ['angel', 'Ангельські крила'], ['dragon', 'Драконячі крила'], ['neon', 'Неонові крила'], ['flame', "Полум'яні крила"], ['astral', 'Астральні крила']];
  const HATS = [['chinese', 'Китайська шляпа'], ['amethyst', 'Корона аметисту'], ['neon', 'Неонова корона'], ['mage', 'Капелюх мага'], ['samurai', 'Самурайський шолом'], ['horns', 'Диявольські роги']];
  const WPNS = [['shadow', 'Меч тіні'], ['flame', "Полум'яний меч"], ['ice', 'Крижаний меч'], ['neon', 'Неоновий меч'], ['katana', 'Катана'], ['axe', 'Сокира дракона'], ['staff', 'Жезл аркани'], ['bow', 'Лук душ']];
  const ANIMS = [['dance', 'Емоція танцю (клавіша G)', 'animDance'], ['meditate', 'Медитація', 'animMeditate'], ['fly', 'Летюче сяйво', 'animFly'], ['trail', 'Сліди при ходьбі', 'animTrail'], ['afk', 'AFK анімація', 'animAfk'], ['hit', 'Ефект удару', 'hitFx']];
  const KILLS = [['blood', 'Кривавий сплеск'], ['souls', 'Душі ворога'], ['burst', 'Вибух частинок']];
  const PALS = ['Фіолет', 'Білий', 'Вогонь', 'Синій', 'Зелений', 'Електрика', 'Крижаний', 'Душі'];
  const DEF = { cosOn: true, cosGlow: true, cosFlap: true, cosWings: 0, cosHat: 0, cosWeapon: 0, cosPal: 0, cosKill: 0, cosR: 1, cosG: 1, cosB: 1, cosScale: 1,
    animDance: false, animMeditate: false, animFly: false, animTrail: false, animAfk: false, hitFx: true, customCos: [] };
  const cos = Object.assign({}, DEF, store.get('cos', {}));
  const saveCos = () => store.set('cos', cos);
  let baseCfg = null;

  function cardGrid(box, defs, prefix, key, type) {
    box.textContent = '';
    const customs = cos.customCos.filter(c => c.type === type);
    const items = [{ label: 'Немає', img: null }].concat(defs.map(d => ({ label: d[1], img: `img/cos/${prefix}_${d[0]}.png` })), customs.map(c => ({ label: '★ ' + c.name, img: null })));
    items.forEach((it, i) => {
      const c = el('button', 'card' + (cos[key] === i ? ' sel' : ''));
      if (it.img) { const im = el('img'); im.src = it.img; im.alt = ''; c.appendChild(im); } else c.appendChild(el('div', 'noimg', i === 0 ? '∅' : '★'));
      c.appendChild(document.createTextNode(it.label));
      c.addEventListener('click', () => { cos[key] = i; saveCos(); cardGrid(box, defs, prefix, key, type); });
      box.appendChild(c);
    });
  }
  function setSw(btn, on) { btn.classList.toggle('on', !!on); }
  function wireSw(id, key) { const b = $(id); setSw(b, cos[key]); b.addEventListener('click', () => { cos[key] = !cos[key]; saveCos(); setSw(b, cos[key]); }); }
  function renderCos() {
    cardGrid($('#c-wings'), WINGS, 'wing', 'cosWings', 0);
    cardGrid($('#c-hat'), HATS, 'hat', 'cosHat', 1);
    cardGrid($('#c-wpn'), WPNS, 'wpn', 'cosWeapon', 2);
    // пресети вбивства
    const kb = $('#c-kill'); kb.textContent = '';
    [['own', 'Свій']].concat(KILLS).forEach((k, i) => {
      const c = el('button', 'card' + (cos.cosKill === i ? ' sel' : ''));
      if (i > 0) { const im = el('img'); im.src = `img/cos/kill_${k[0]}.png`; im.alt = ''; c.appendChild(im); } else c.appendChild(el('div', 'noimg', '∅'));
      c.appendChild(document.createTextNode(k[1]));
      c.addEventListener('click', () => { cos.cosKill = i; saveCos(); renderCos(); });
      kb.appendChild(c);
    });
    const pb = $('#c-pal'); pb.textContent = '';
    PALS.forEach((n, i) => { const c = el('button', 'chip' + (cos.cosPal === i ? ' sel' : ''), n); c.addEventListener('click', () => { cos.cosPal = i; saveCos(); renderCos(); }); pb.appendChild(c); });
    const ab = $('#c-anim'); ab.textContent = '';
    ANIMS.forEach(a => {
      const t = el('div', 'tog'), im = el('img'); im.src = `img/cos/anim_${a[0]}.png`; im.alt = '';
      const sw = el('button', 'sw' + (cos[a[2]] ? ' on' : '')); sw.addEventListener('click', () => { cos[a[2]] = !cos[a[2]]; saveCos(); sw.classList.toggle('on', cos[a[2]]); });
      t.append(im, el('span', '', a[1]), sw); ab.appendChild(t);
    });
    const nl = $('#n-list'); nl.textContent = '';
    cos.customCos.forEach(c => {
      const row = el('div', 'item'); const tx = el('div', 'tx'); tx.appendChild(el('b', '', '★ ' + c.name)); tx.appendChild(el('small', '', ['Крила', 'Капелюх', 'Зброя'][c.type] + ' · ' + PALS[c.palette]));
      const b = el('button', 'btn sm', 'Видалити'); b.addEventListener('click', () => { cos.customCos = cos.customCos.filter(x => x !== c); fixSel(); saveCos(); renderCos(); });
      row.append(tx, b); nl.appendChild(row);
    });
  }
  function fixSel() {
    const max = t => (t === 0 ? WINGS : t === 1 ? HATS : WPNS).length + cos.customCos.filter(c => c.type === t).length;
    if (cos.cosWings > max(0)) cos.cosWings = 0; if (cos.cosHat > max(1)) cos.cosHat = 0; if (cos.cosWeapon > max(2)) cos.cosWeapon = 0;
  }
  function initCos() {
    wireSw('#c-on', 'cosOn'); wireSw('#c-glow', 'cosGlow'); wireSw('#c-flap', 'cosFlap');
    [['r', 'cosR'], ['g', 'cosG'], ['b', 'cosB']].forEach(([id, k]) => {
      const inp = $('#c-' + id), out = $('#v-' + id); inp.value = Math.round(cos[k] * 100); out.textContent = inp.value + '%';
      inp.addEventListener('input', () => { cos[k] = inp.value / 100; out.textContent = inp.value + '%'; saveCos(); });
    });
    const s = $('#c-s'); s.value = Math.round(cos.cosScale * 100); $('#v-s').textContent = s.value + '%';
    s.addEventListener('input', () => { cos.cosScale = s.value / 100; $('#v-s').textContent = s.value + '%'; saveCos(); });
    const sel = $('#n-pal'); PALS.forEach((n, i) => { const o = el('option', '', n); o.value = i; sel.appendChild(o); });
    $('#n-add').addEventListener('click', () => {
      const name = $('#n-name').value.trim();
      if (!name) { toast('Впиши назву'); return; }
      const type = +$('#n-type').value;
      cos.customCos.push({ id: name.toLowerCase().replace(/[^a-z0-9_]/g, '') + '_' + (Date.now() % 1000000), name: name.slice(0, 24), type, palette: +$('#n-pal').value });
      const idx = (type === 0 ? WINGS : type === 1 ? HATS : WPNS).length + cos.customCos.filter(c => c.type === type).length;
      cos[type === 0 ? 'cosWings' : type === 1 ? 'cosHat' : 'cosWeapon'] = idx;
      $('#n-name').value = ''; saveCos(); renderCos(); toast('Додано й вибрано: ' + name);
    });
    $('#c-import').addEventListener('change', async e => {
      const f = e.target.files[0]; if (!f) return;
      try { baseCfg = JSON.parse(await f.text()); $('#c-msg').className = 'err ok'; $('#c-msg').textContent = 'Імпортовано: решта налаштувань збережеться'; }
      catch { baseCfg = null; $('#c-msg').className = 'err'; $('#c-msg').textContent = 'Не вдалося прочитати файл'; }
    });
    $('#c-export').addEventListener('click', exportCfg);
    renderCos();
  }
  function buildCfg(base) {
    const o = Object.assign({}, base || {});
    ['cosOn', 'cosGlow', 'cosFlap', 'cosWings', 'cosHat', 'cosWeapon', 'cosPal', 'cosKill', 'cosR', 'cosG', 'cosB', 'cosScale', 'animDance', 'animMeditate', 'animFly', 'animTrail', 'animAfk', 'hitFx'].forEach(k => { o[k] = cos[k]; });
    const have = new Map((o.customCos || []).map(c => [c.id, c]));
    cos.customCos.forEach(c => { if (!have.has(c.id)) have.set(c.id, { id: c.id, name: c.name, type: c.type, palette: c.palette, png: '' }); });
    o.customCos = [...have.values()];
    if (cos.cosKill > 0) {   // те саме, що робить мод при виборі пресета вбивства
      o.killFx = true; o.fxRainbow = false;
      if (cos.cosKill === 1) { o.killStyle = 10; o.killShape = 0; o.fxR = 0.75; o.fxG = 0.02; o.fxB = 0.05; o.fxSize = 1.6; }
      else if (cos.cosKill === 2) { o.killStyle = 4; o.killShape = 2; } else { o.killStyle = 8; o.killShape = 0; }
    }
    return o;
  }
  async function exportCfg() {
    if (NP) {   // читаємо наявний конфіг мода, додаємо косметику й записуємо назад
      const path = gameDir() + '/config/novavisuals.json';
      try {
        const cur = await NP.readText({ path });
        let base = baseCfg; if (cur.exists) { try { base = JSON.parse(cur.text); } catch {} }
        await NP.writeText({ path, text: JSON.stringify(buildCfg(base), null, 2) });
        $('#c-msg').className = 'err ok'; $('#c-msg').textContent = 'Збережено в ' + path;
      } catch (e) { $('#c-msg').className = 'err'; $('#c-msg').textContent = 'Не вдалося записати: ' + (e.message || e) + '. Дай доступ до файлів у Профілі.'; }
      return;
    }
    const blob = new Blob([JSON.stringify(buildCfg(baseCfg), null, 2)], { type: 'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'novavisuals.json'; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    $('#c-msg').className = 'err ok'; $('#c-msg').textContent = 'Збережено. Поклади novavisuals.json у папку config профілю гри.';
  }

  // ---------- друзі (API сайту Nova Visuals) ----------
  const siteUrl = () => (store.get('site', '') || (location.pathname.includes('/m/') ? location.origin : '')).replace(/\/+$/, '');
  async function api(path, body) {
    const base = siteUrl();
    if (!base) throw new Error('Вкажи адресу сайту в Профілі');
    const h = { 'Content-Type': 'application/json' }, t = store.get('token', '');
    if (t) h.Authorization = 'Bearer ' + t;
    let r;
    try { r = await fetch(base + '/api/' + path, { method: body === undefined ? 'GET' : 'POST', headers: h, body: body === undefined ? undefined : JSON.stringify(body), signal: AbortSignal.timeout(25000) }); }
    catch { throw new Error('Сайт недоступний за адресою ' + base); }
    let j = null; try { j = await r.json(); } catch {}
    if (!r.ok || !j) { const e = new Error((j && j.error) || 'Сайт відповів не так, як очікується (HTTP ' + r.status + ')'); e.status = r.status; throw e; }
    return j;
  }
  let fmode = 'login', fTimer = null;
  $$('#f-login .seg button').forEach(b => b.addEventListener('click', () => {
    fmode = b.dataset.m; $$('#f-login .seg button').forEach(x => x.classList.toggle('active', x === b)); $('#f-go').textContent = fmode === 'login' ? 'Увійти' : 'Створити акаунт';
  }));
  async function fAuth() {
    $('#f-err').textContent = '';
    try { const r = await api(fmode, { name: $('#f-name').value.trim(), password: $('#f-pw').value }); store.set('token', r.token); store.set('user', r.name); $('#f-pw').value = ''; refreshWho(); loadFriends(); }
    catch (e) { $('#f-err').textContent = e.message; }
  }
  $('#f-go').addEventListener('click', fAuth);
  $('#f-pw').addEventListener('keydown', e => { if (e.key === 'Enter') fAuth(); });
  function frow(name, sub, on, btns) {
    const it = el('div', 'item'); it.appendChild(el('span', 'dot' + (on ? ' on' : '')));
    const tx = el('div', 'tx'); tx.appendChild(el('b', '', name)); if (sub) tx.appendChild(el('small', '', sub)); it.appendChild(tx);
    btns.forEach(([l, fn]) => { const b = el('button', 'btn sm', l); b.addEventListener('click', fn); it.appendChild(b); }); return it;
  }
  const ago = ms => { const m = Math.round((Date.now() - ms) / 60000); return !ms ? '' : m < 1 ? ' · щойно' : m < 60 ? ' · ' + m + ' хв тому' : m < 1440 ? ' · ' + Math.round(m / 60) + ' год тому' : ' · ' + Math.round(m / 1440) + ' дн тому'; };
  async function loadFriends() {
    clearTimeout(fTimer);
    const authed = !!store.get('token', '');
    $('#f-login').classList.toggle('hidden', authed); $('#f-main').classList.toggle('hidden', !authed);
    if (!authed || !$('#p-friends').classList.contains('active')) return;
    try {
      const f = await api('friends');
      const L = $('#f-list'), I = $('#f-in'), O = $('#f-out'); L.textContent = I.textContent = O.textContent = '';
      f.friends.forEach(u => L.appendChild(frow(u.name, u.online ? (u.inGame ? 'У грі' + (u.server ? ' · ' + u.server : '') : 'У лаунчері') : 'Офлайн' + ago(u.lastSeen), u.online, [['Видалити', () => fdo('remove', u.name)]])));
      f.incoming.forEach(n => I.appendChild(frow(n, 'хоче додати тебе', false, [['Прийняти', () => fdo('accept', n)], ['✕', () => fdo('decline', n)]])));
      f.outgoing.forEach(n => O.appendChild(frow(n, 'очікує відповіді', false, [])));
      $('#f-empty').classList.toggle('hidden', f.friends.length > 0); $('#f-inh').classList.toggle('hidden', !f.incoming.length); $('#f-outh').classList.toggle('hidden', !f.outgoing.length);
      fTimer = setTimeout(loadFriends, 15000);
    } catch (e) { $('#f-err2').textContent = e.message; if (e.status === 401) { store.set('token', ''); loadFriends(); } }
  }
  async function fdo(a, n) { try { await api('friends/' + a, { name: n }); loadFriends(); } catch (e) { toast(e.message); } }
  $('#f-addgo').addEventListener('click', async () => {
    $('#f-err2').textContent = '';
    const v = $('#f-add').value.trim();
    if (!/^[A-Za-z0-9_]{3,16}$/.test(v)) { $('#f-err2').textContent = 'Нік: 3-16 символів, латиниця, цифри, _'; return; }
    try { const r = await api('friends/add', { name: v }); $('#f-add').value = ''; toast(r.status === 'friends' ? 'Ви тепер друзі' : 'Запит надіслано'); loadFriends(); }
    catch (e) { $('#f-err2').textContent = e.message; }
  });

  // ---------- профіль ----------
  function refreshWho() {
    const u = store.get('user', ''), n = store.get('nick', '');
    $('#who').textContent = u || '';
    $('#p-nick').value = n; $('#p-nick-v').textContent = n || 'Гравець'; $('#p-acc').textContent = u ? 'Акаунт на сайті: ' + u : 'Не увійшов на сайт';
    const h = $('#p-head'); if (n) h.src = 'https://minotar.net/helm/' + encodeURIComponent(n) + '/64'; else h.removeAttribute('src');
    $('#p-site').value = store.get('site', '') || (location.pathname.includes('/m/') ? location.origin : '');
  }
  $('#p-save').addEventListener('click', () => {
    const n = $('#p-nick').value.trim();
    if (n && !/^[A-Za-z0-9_]{3,16}$/.test(n)) { toast('Нік: 3-16 символів, латиниця, цифри, _'); return; }
    store.set('nick', n); refreshWho(); toast('Збережено');
  });
  $('#p-sitesave').addEventListener('click', () => {
    const v = $('#p-site').value.trim().replace(/\/+$/, '');
    if (v && !/^https?:\/\/[^\s/]+(:\d+)?$/i.test(v)) { $('#p-err').textContent = 'Адреса має вигляд https://novavisuals.example'; return; }
    $('#p-err').textContent = ''; store.set('site', v); toast('Адресу сайту збережено');
  });
  $('#p-logout').addEventListener('click', () => { api('logout', {}).catch(() => {}); store.set('token', ''); store.set('user', ''); refreshWho(); toast('Ти вийшов з акаунта'); });
  $('#p-reset').addEventListener('click', () => { if (confirm('Скинути всі дані застосунку на цьому пристрої?')) { Object.keys(localStorage).filter(k => k.startsWith('nv.')).forEach(k => localStorage.removeItem(k)); location.reload(); } });

  // ---------- ГРАТИ й налаштування Android ----------
  async function refreshNative() {
    if (!NP) return;
    $('#p-dir').value = gameDir();
    $('#p-app').value = store.get('app', 'auto');
    try {
      const i = await NP.info();
      const names = [i.apps.pojav && 'PojavLauncher', i.apps.zalith && 'Zalith', i.apps.fcl && 'FCL'].filter(Boolean);
      $('#p-state').textContent = (i.allFiles ? 'Доступ до файлів: є' : 'Доступ до файлів: немає (натисни «Доступ до файлів»)') + ' · Знайдено: ' + (names.join(', ') || 'нічого');
      $('#play-hint').textContent = names.length ? 'Запустить: ' + names.join(' / ') : 'Встанови PojavLauncher, Zalith або FCL, щоб грати';
    } catch {}
  }
  if (NP) {
    $('#play').addEventListener('click', async () => {
      const pick = store.get('app', 'auto');
      const pk = pick === 'auto' ? [].concat(APP_PKGS.pojav, APP_PKGS.zalith, APP_PKGS.fcl) : APP_PKGS[pick];
      try { const r = await NP.launch({ packages: pk }); if (!r.launched) toast('Не знайшов програму для запуску Java-версії. Встанови PojavLauncher, Zalith або FCL.'); }
      catch (e) { toast(e.message || 'Не вдалося запустити'); }
    });
    $('#p-dirsave').addEventListener('click', () => { const v = $('#p-dir').value.trim() || GAME_DEF; if (!v.startsWith('/storage/')) { toast('Шлях має починатися з /storage/'); return; } store.set('gameDir', v); store.set('app', $('#p-app').value); toast('Збережено'); refreshNative(); });
    $('#p-files').addEventListener('click', async () => { try { await NP.requestAllFiles(); toast('Увімкни доступ до файлів і повернись у застосунок'); } catch (e) { toast(e.message || 'Не вдалося відкрити налаштування'); } });
    document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshNative(); });
    refreshNative();
  }

  initCos(); refreshWho();
  const h = (location.hash || '').slice(1); if (['home', 'mods', 'cos', 'friends', 'profile'].includes(h)) go(h);
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});
})();
