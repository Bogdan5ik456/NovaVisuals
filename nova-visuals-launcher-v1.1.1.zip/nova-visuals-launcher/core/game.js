// Підготовка та запуск Minecraft (Fabric)
const { Client } = require('minecraft-launcher-core');
const paths = require('./paths');
const { ensureJava } = require('./java');
const fabric = require('./fabric');
const auth = require('./auth');
const skin = require('./skin');
const site = require('./site');
const { online } = require('./util');

let running = false;

// Налаштування Java для стабільнішого FPS (менше пауз збирача сміття)
const JVM_FLAGS = ['-XX:+UnlockExperimentalVMOptions', '-XX:+UseG1GC', '-XX:+ParallelRefProcEnabled', '-XX:MaxGCPauseMillis=200',
  '-XX:+DisableExplicitGC', '-XX:G1NewSizePercent=30', '-XX:G1MaxNewSizePercent=40', '-XX:G1HeapRegionSize=8M',
  '-XX:G1ReservePercent=20', '-XX:G1HeapWastePercent=5', '-XX:G1MixedGCCountTarget=4', '-XX:InitiatingHeapOccupancyPercent=15',
  '-XX:G1MixedGCLiveThresholdPercent=90', '-XX:G1RSetUpdatingPauseTimePercent=5', '-XX:SurvivorRatio=32',
  '-XX:+PerfDisableSharedMem', '-XX:MaxTenuringThreshold=1'];

async function launchGame(o, send) {
  if (running) throw new Error('Гра вже запущена');
  running = true;
  try {
    const { version, ram, res, authType, nick } = o;
    if (!['1.21.11', '1.18.2'].includes(version)) throw new Error('Непідтримувана версія');

    // Мод кладемо в папку mods ОДРАЗУ (діагностичний режим без мода вмикається вручну в налаштуваннях)
    if (o.noNova) fabric.removeNovaMod(version);
    else { try { fabric.installNovaMod(version); } catch (e) { send('log', { text: 'Мод Nova Visuals: ' + e.message }); } }

    const java = await ensureJava(version === '1.18.2' ? 17 : 21, (text, percent) => send('progress', { text, percent }));
    const custom = await fabric.ensureFabric(version, send);
    await fabric.ensureFabricApi(version, send);
    if (o.fpsBoost !== false) await fabric.ensureFpsMod(version, send); else fabric.removeFpsMod(version);
    try { skin.applySkin(version, authType !== 'microsoft', t => send('log', { text: t })); } catch (e) { send('log', { text: 'Скін: ' + e.message }); }

    try { site.writeLink(version); } catch (e) { send('log', { text: 'Сайт: ' + e.message }); }   // мод бачить друзів онлайн

    send('progress', { text: 'Вхід в акаунт…', percent: 100 });
    let authorization;
    if (authType === 'microsoft') {
      try { authorization = await auth.microsoftAuthorization(); }
      catch (e) {
        if (await online()) throw e;   // інтернет є — це справжня помилка входу
        const prof = auth.microsoftStatus();
        authorization = auth.offlineAuthorization((prof && prof.name) || nick || 'Player');
        send('log', { text: 'Немає інтернету: запуск в офлайн-режимі' });
      }
    } else {
      if (!/^[A-Za-z0-9_]{3,16}$/.test(nick || '')) throw new Error('Некоректний нік');
      authorization = auth.offlineAuthorization(nick);
    }

    const win = res === 'full' ? { fullscreen: true } : (() => { const [w, h] = String(res).split('x').map(Number); return { width: w || 1280, height: h || 720 }; })();
    const client = new Client();
    client.on('progress', e => e.total && send('progress', { text: `Завантаження: ${e.type}`, percent: Math.round(e.task / e.total * 100) }));
    client.on('download-status', e => send('progress', { text: `Завантаження: ${e.name}`, percent: e.total ? Math.round(e.current / e.total * 100) : 0 }));
    client.on('debug', t => send('log', { text: String(t) }));
    client.on('data', t => send('log', { text: String(t) }));

    send('progress', { text: 'Запуск Minecraft…', percent: 100 });
    const proc = await client.launch({
      authorization,
      root: paths.root,
      javaPath: java.javaw,
      version: { number: version, type: 'release', custom },
      memory: (() => { const m = Math.max(1024, Math.min(+ram || 4096, 16384)); return { max: `${m}M`, min: `${m}M` }; })(),
      window: win,
      customArgs: JVM_FLAGS,
      overrides: { gameDirectory: paths.instance(version) }
    });
    if (!proc) throw new Error('Не вдалося запустити Minecraft. Дивись журнал нижче.');
    send('started', {});
    proc.on('close', code => { running = false; send('closed', { code }); });
  } catch (e) {
    running = false;
    const netLike = /fetch|network|ENOTFOUND|ECONN|EAI_AGAIN|getaddrinfo|timeout|Помилка завантаження|Не вдалося отримати|Modrinth/i.test(String(e && e.message));
    if (netLike && !(await online())) {
      throw new Error('Немає інтернету. Версію потрібно один раз завантажити з мережі, після цього вона запускатиметься офлайн.');
    }
    throw e;
  }
}

module.exports = { launchGame };
